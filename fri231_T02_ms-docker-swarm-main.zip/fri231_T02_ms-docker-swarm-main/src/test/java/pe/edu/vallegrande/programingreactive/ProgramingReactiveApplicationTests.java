package pe.edu.vallegrande.programingreactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgramingReactiveApplicationTests {

    @Test
    void contextLoads() {
    }

}
