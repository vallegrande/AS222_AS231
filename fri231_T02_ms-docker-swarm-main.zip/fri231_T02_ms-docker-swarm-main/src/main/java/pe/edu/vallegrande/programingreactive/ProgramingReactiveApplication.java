package pe.edu.vallegrande.programingreactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgramingReactiveApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProgramingReactiveApplication.class, args);
    }

}
