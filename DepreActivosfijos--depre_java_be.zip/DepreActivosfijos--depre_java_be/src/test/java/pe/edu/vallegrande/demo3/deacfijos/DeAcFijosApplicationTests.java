package pe.edu.vallegrande.demo3.deacfijos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeAcFijosApplicationTests {

    @Test
    void contextLoads() {
    }

}
